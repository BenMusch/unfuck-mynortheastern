document.addEventListener("keydown", function(b){if((b.metaKey||b.ctrlKey)&&70==b.keyCode) b.stopPropagation()})
